#include<stdio.h>

int main(){
    printf("\"これは「\"」記号を表示するプログラムです\"\n");
    return 0;
}